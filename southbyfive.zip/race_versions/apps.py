from django.apps import AppConfig


class RaceVersionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'race_versions'
